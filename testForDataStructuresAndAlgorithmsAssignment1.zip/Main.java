import java.util.Scanner;
import java.util.*;
import java.util.HashMap;
import java.util.TreeMap;

class Main {

  //Class to create the node
  class Node {
    String states;//Data for states
    String capitals;//Data for capitals
    //Create leftChild and rightChild
    Node leftChild;
    Node rightChild;

    Node (String states, String capitals) {//method to initialize the node
      this.states = states;
      this.capitals = capitals;
      leftChild = rightChild = null;
    }
  }

  //Create the root node
  Node root;
  //Method for the root node and set equal to null
  public Main() {
    root = null;
  }

  //Insert method for new values in the tree
  public void insert(String States, String Capitals) {
    root = insertNode(root, States, Capitals);
  }
  //Recursive function to insert from the root into the right place
  public Node insertNode(Node node, String States, String Capitals) {
    if (node == null) {//If node is empty put values into node
      node = new Node(States, Capitals);
      return node;
    }

    if (States.compareTo(node.states) <= 0) {
      //If the state is less than the current state of the node call insertNode with leftChild
      node.leftChild = insertNode(node.leftChild, States, Capitals);
    } else  {
      //If the state is greater than the current state of the node call insertNode with rightChild
      node.rightChild = insertNode(node.rightChild, States, Capitals);
    }
    return node;
  }

  //Find method asking for the node to find
  public Node find(String state) {
    Node node = findNode(root, state);
    return node;
  }
  //Recursive method to find the entered value
  public Node findNode(Node node, String state) {
    if (state.compareTo(node.states) == 0) {
      //If entered state is equal to the state in the node return node
      return node;
    }

    if (state.compareTo(node.states) < 0) {
      if(node.leftChild == null) return null; //If next node is null return null
      //If state is less than state in node call findNode with leftChild
      return findNode(node.leftChild, state);
    } else if (state.compareTo(node.states) > 0) {
      if (node.rightChild == null) return null;//If next node is null return null
      //If state is greater than state in node call findNode with rightChild
      return findNode(node.rightChild, state);
    }
    //If no node is found with a matching state return null
    return null;
  }

  
  public static void main(String[] args) {
    //Creating and Filling the two dimensional array
    String[][] StatesAndCapitals = {{"Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennesse", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"},{"Montgomery", "Juneau", "Phoenix", "Little Rock", "Sacremento", "Denver", "Hartford", "Dover", "Tallahassee", "Atlanta", "Honolulu", "Boise", "Springfield", "Indianapolis", "Des Moines", "Topeka", "Frankfort", "Baton Rouge", "Augusta", "Annapolis", "Boston", "Lansing", "St. Paul", "Jackson", "Jefferson City", "Helena", "Lincoln", "Carson City", "Concord", "Trenton", "Santa Fe", "Albany", "Raleigh", "Bismarck", "Columbus", "Oklahoma City", "Salem", "Harrisburg", "Providence", "Columbia", "Pierre", "Nashville", "Austin", "Salt Lake City", "Montpelier", "Richmond", "Olympia", "Charleston", "Madison", "Cheyenne"}};

    //Data Structures and Algorithms assignment part one
    
    //Loop to display StatesAndCapitals array sorted by state
    for (int i = 0; i<StatesAndCapitals[0].length; i ++) {
      //Print statement for the states
      System.out.print(StatesAndCapitals[0][i] + "             ");
      //Print statement for the Capitals
      System.out.println(StatesAndCapitals[1][i]);
     
    }
    //Loop to bubble sort StatesAndCapitals array by capital
    for (int i = 0; i < StatesAndCapitals[0].length-1; i++) {
      for (int j = 0; j < StatesAndCapitals[0].length-i-1; j++) {
        int comp = StatesAndCapitals[1][j].compareTo(StatesAndCapitals[1][j+1]);
        if (comp > 0) {
          String temp1 = StatesAndCapitals[1][j];
          String temp2 = StatesAndCapitals[0][j];
          StatesAndCapitals[1][j] = StatesAndCapitals[1][j+1];
          StatesAndCapitals[0][j] = StatesAndCapitals[0][j+1];
          StatesAndCapitals[1][j+1] = temp1;
          StatesAndCapitals[0][j+1] = temp2;

        }
      }
    }
    //Initialize scanner class to recieve user input
    Scanner userInput = new Scanner(System.in);
    //Initialize StringBuilder class
    StringBuilder str = new StringBuilder();
    //Counter to count number of correct answers
    int counter = 0;
    //Temp array to hold correct entered capitals so they aren't counted if they are entered again
    ArrayList<String> tempHolder = new ArrayList();
    //Prompt for the user to enter capitals for all 50 states
    System.out.println("Enter capitals for all 50 states");

    //Loop to ask user for all 50 capitals
    for (int i = 0; i<StatesAndCapitals[0].length; i++) {
        str.delete(0, str.length());//Empty the StringBuilder for the next loop
        str.append(userInput.nextLine());//Put user entered string into StringBuilder
        
        if (str.length() < 1) {//If nothing was entered continue to next loop
          continue;
        } 

        String tempL = str.substring(0, str.length());//Temporary string variable of StringBuilder
        String L = tempL.toLowerCase();// Make the entire string lowercase
        str.replace(0, str.length(), L);//Put the all lowercase string back into StringBuilder
        String temp = str.substring(0, 1);//temp variable to store letter to uppercase
        String t = temp.toUpperCase();//Change the temp variable to uppercase
        str.replace(0, 1, t);//Replace lowercase letter with uppercase letter

        if (str.indexOf(" ") != -1) {//check if there is a space in the entered string
          int temp1 = str.indexOf(" ");//Get the index of the space in the string
          if (temp1 + 1 >= str.length()) continue;//If the space is the last letter of the string continue
          String temp2 = str.substring(temp1 + 1, temp1 + 2);//variable to hold lowercase letter
          String tt = temp2.toUpperCase();//Change letter to uppercase
          str.replace(temp1 + 1, temp1 + 2, tt);//replace lowercase letter with uppercase letter
          if (str.indexOf(" ", temp1 + 1) != -1) {// Check if there is another space in the string after the first one
            int temp3 = str.indexOf(" ", temp1 + 1);//Get index of second space
            if (temp3 + 1 >= str.length()) continue;//If second space is last letter of string continue
            String temp4 = str.substring(temp3 + 1, temp3 + 2);//Variable to hold lowercase letter
            String ttt = temp4.toUpperCase();//Change letter to uppercase
            str.replace(temp3 + 1, temp3 + 2, ttt);//Replace lowercase letter with uppercase letter
          }
          
        }

        for (int j = 0; j < StatesAndCapitals[0].length; j++) {//Loop to compare user answer to values in array
          String tempCompare = str.toString();//Temp string variable for comparison
          if (StatesAndCapitals[1][j].compareTo(tempCompare) == 0) {//If statement to compare string variable and array value
            if (tempHolder.contains(tempCompare)) {
              break;
            }
            else {
              tempHolder.add(tempCompare);//Place the correct user entered value in an temp array
              counter++;
              System.out.println("Capital " + tempCompare + " Found in array!");
            }
            
          }
        }


        
    }
    //Output the total number of correct capitals
    System.out.println("Total number of correct capitals entered: " + counter);
    System.out.println();
    //Data Structures and Algorithms assignment part 2
    
    //Initializing Hash Map
    HashMap<String, String> statesAndCapitalsHash = new HashMap<>();
    //For loop to input StatesAndCapitals array in Hash Map
    for (int i = 0; i < StatesAndCapitals[0].length; i++) {
      statesAndCapitalsHash.put(StatesAndCapitals[0][i], StatesAndCapitals[1][i]);
    }
    //Output HashMap
    System.out.println(statesAndCapitalsHash);
    System.out.println();
    //Initializing Tree Map
    TreeMap<String, String> statesAndCapitalsTree = new TreeMap<>();
    //For loop to input StatesAndCapitals array in Tree Map
    for (int i = 0; i < StatesAndCapitals[0].length; i++) {
      statesAndCapitalsTree.put(StatesAndCapitals[0][i], StatesAndCapitals[1][i]);
    }

    //Initialize binary tree
    Main binaryTree = new Main();
    //ForEach loop to put values into binary search tree
    for (String key : statesAndCapitalsHash.keySet()) {
      //Call to insert function for binary search tree
      binaryTree.insert(key, statesAndCapitalsHash.get(key));
    }

    //Create the input for the user to enter the state
    Scanner enteredState = new Scanner(System.in);
    //Create a StringBuilder to make entered state case sensative
    StringBuilder strFix = new StringBuilder();
    //Ask the user to enter a state
    System.out.println("Enter a state");

    strFix.append(enteredState.nextLine());//Put user entered string into StringBuilder
        
    if (strFix.length() < 1) {//If nothing was entered output no state entered
          System.out.println("No State was entered");
      } else {

          String tempL = strFix.substring(0, strFix.length());//Temporary string variable of StringBuilder
          String L = tempL.toLowerCase();// Make the entire string lowercase
          strFix.replace(0, strFix.length(), L);//Put the all lowercase string back into StringBuilder
          String temp = strFix.substring(0, 1);//temp variable to store letter to uppercase
          String t = temp.toUpperCase();//Change the temp variable to uppercase
          strFix.replace(0, 1, t);//Replace lowercase letter with uppercase letter
  
          if (strFix.indexOf(" ") != -1) {//check if there is a space in the entered string
            int temp1 = strFix.indexOf(" ");//Get the index of the space in the string
            if (temp1 + 1 < strFix.length()) {//If the space is not the last letter of the string capitalize the letter after the space
              String temp2 = strFix.substring(temp1 + 1, temp1 + 2);//variable to hold lowercase letter
              String tt = temp2.toUpperCase();//Change letter to uppercase
              strFix.replace(temp1 + 1, temp1 + 2, tt);//replace lowercase letter with uppercase letter
            }
            
          }
        }
    //Case sensitive string to be used to search binary tree
    String entValue = strFix.substring(0, strFix.length());
    if (binaryTree.find(entValue) == null) {
      //If no matching value is found in the BST output state not found
      System.out.println("State not found in BST");
    } else {
      //If matching value is found output capital
      System.out.println("The capital for " + entValue + " is " + binaryTree.find(entValue).capitals);
    }
  }
}
